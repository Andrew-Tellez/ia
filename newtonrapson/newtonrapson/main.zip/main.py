import matplotlib.pyplot as plt
import numpy as np


def newton_raphson(f, df, x, tol=1e-6, max_iter=100):
    for i in range(max_iter):
        f_value = f(x)
        f_prime_value = df(x)

        if f_prime_value == 0 :
            return None
        # Evitar división por cero
        if abs(f_prime_value) < 1e-6:
            raise ValueError("La derivada es muy pequeña, posible división por cero.")

        # Método de Newton-Raphson
        # print(f"x_vieja={x}",end=" ")
        x = x - f_value / f_prime_value

        # print(f"x_nueva={x} f={f_value}")
        # Comprobar la convergencia
        if abs(f_value) < tol:
            return x

    raise ValueError(
        "El método de Newton-Raphson no converge después de {} iteraciones.".format(
            max_iter
        )
    )


if __name__ == "__main__":
    raices = []

    # Definir la función y su derivada
    def f(x):
        # return x**2 - 2
        # return x**3-2*x-5
        return np.sin(np.pi * x)

    def df(x):
        # return 2 * x
        # return 3*x**2-2
        return np.pi * (np.cos(np.pi * x))

    # Calcular las raíces utilizando el método de Newton-Raphson
    valores_iniciales = range(-10, 11)
    for x0 in valores_iniciales:
        root_approximation = newton_raphson(f, df, x0)
        if root_approximation is not None:
        # print("Aproximación de la raíz:", root_approximation)
        # print(f"funcion a cero: f({root_approximation})={f(root_approximation)}")
            raices.append(round(root_approximation, 6))

    conjunto_raices = list(set(raices))
    print(conjunto_raices)

    x_valores = np.linspace(-10, 11)
    y_valores = f(x_valores)
    # "f(x)=sin(pi * x)"
    # "f(x)=x^2-2"
    funcion = "f(x)=x^2-2"
    plt.plot(x_valores, y_valores, label=funcion)
    plt.xlabel("x")

    plt.axhline(0, color="black", linestyle="--", linewidth=1.0)

    datos = {
        "x": conjunto_raices,
        "y": np.zeros(len(conjunto_raices))
    }
    plt.scatter("x", "y", color="red", marker="o" ,data=datos,label="raíces")

    for e in datos["x"]:
        plt.axvline(e,0, color="green", linestyle="--", linewidth=1.0)

    plt.ylabel("f(x)")
    plt.title("Grafico del metodo de newton raphson")
    plt.legend()
    plt.show()
